#!/usr/bin/php
<?php
require_once('path.inc');
require_once('get_host_info.inc');
require_once('rabbitMQLib.inc');

echo "Starting update for front-end".PHP_EOL;

$filename = "frontendPackage.";
$version = "1.0";

exec("find /home/ubuntu/git/IT4902020/packages -printf '%T+ %p\n' | sort -r | head", $output);

if(!empty($output))
{
	$fileVersion = explode('.', $output[0]);

	echo $fileVersion.PHP_EOL;

	$version = (int)$fileVersion[count($fileVersion)-1];

	echo "Version check ".$version.PHP_EOL;

	if((int)$version == 9)
	{
		$version = "9.1";
	}
	else
	{
		$version += 1;
	}

	$filename = "frontendPackage." . $version . ".+.tar.gz";
}
else
{
	$filename = $filename . $version . ".+.tar.gz";
}

echo "Current version: ". $version.PHP_EOL;

exec("tar -czvf $filename --exclude='/home/ubuntu/git/IT4902020/WebServer/listenDisLog.php /home/ubuntu/git/IT4902020/WebServer/frontEndDeploymentClient.php' /home/ubuntu/git/IT4902020/WebServer", $output, $return_val);

exec("mv  /home/ubuntu/git/IT4902020/WebServer/$filename /home/ubuntu/git/IT4902020/packages/");
exec("scp /home/ubuntu/git/IT4902020/packages/$filename ubuntu@10.0.1.40:~/git/IT4902020/deployment/frontEnd/");

print_r($output);

$client = new rabbitMQClient("testRabbitMQ.ini","brandonServer");

$request = array();
$request['type'] = "update";
$request['server'] = "frontEnd";
$request['version'] = $version;

$response = $client->send_request($request);

echo "client received response: ".PHP_EOL;

print_r($response);
echo "\n\n";

echo $argv[0]." END".PHP_EOL;
