#!/usr/bin/php
<?php

require_once('rabbitMQLib.inc');
require_once('path.inc');
require_once('get_host_info.inc');

echo "Now Listening for Updates".PHP_EOL;

function UpdateFiles($version)
{
        print_r( "VERSION: ".$version.PHP_EOL);

        exec("tar -C . -xvf /home/ubuntu/git/IT4902020/packages/frontEndPackage.$version.+.tar.gz");
}

function RollbackVersion()
{
        exec("ls -t ../packages", $output);

        if(count($output) < 2)
        {
                echo "Cannot rollback, nothing to rollback to";
                return;
        }

        $version = $output[1][1];

        echo "Rolling back from version $version";

        $filename = "frontendPackage.$version.+.tar.gz";
        echo "Rolling back to most recent, good backup";

        exec("mv listenUpdate.php ../");

        $badfile = str_replace("+", "-", $filename);
        exec("mv ../packages/$filename ../packages/$badfile");

        exec("rm -r *");

        UpdateFiles($version);
}

function requestProcessor($request)
{

        switch($request['type'])
        {
                case 'update':
                        print_r("Received Update");
                        UpdateFiles($request['version']);
                        return 1;

                case 'rollback':
                        print_r("Received Rollback Request");
                        RollbackVersion();
                        return 1;
        }
}

$server = new rabbitMQServer("testRabbitMQ.ini", "brandonServer");

$server->process_requests('requestProcessor');

?>
